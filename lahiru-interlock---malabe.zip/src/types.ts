export interface CartItem {
  id: string;
  name: string;
  unitPrice: number;
  unitLabel: string;
  qty: number;
  image?: string;
}

export interface ToastMessage {
  id: string;
  text: string;
}
