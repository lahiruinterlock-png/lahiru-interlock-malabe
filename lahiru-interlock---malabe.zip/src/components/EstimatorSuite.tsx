import React, { useState } from 'react';
import { ShoppingCart, MessageSquare, Truck, Check, HelpCircle } from 'lucide-react';
import { CartItem } from '../types';

interface EstimatorSuiteProps {
  onAddToCart: (item: CartItem) => void;
  showToast: (msg: string) => void;
}

interface BrickOption {
  id: string;
  name: string;
  unitPrice: number;
  coverage: number;
  unitLabel: string;
}

const BRICK_OPTIONS: BrickOption[] = [
  { id: 'opt-8x4-std', name: '8×4 Cement Standard (Rs. 55.00)', unitPrice: 55, coverage: 4.5, unitLabel: 'piece' },
  { id: 'opt-8x4-eco', name: '8×4 Cement Economy (Rs. 45.00)', unitPrice: 45, coverage: 4.5, unitLabel: 'piece' },
  { id: 'opt-8x4-red', name: '8×4 Red Terracotta (Rs. 65.00)', unitPrice: 65, coverage: 4.5, unitLabel: 'piece' },
  { id: 'opt-8x4-blk', name: '8×4 Charcoal Black (Rs. 65.00)', unitPrice: 65, coverage: 4.5, unitLabel: 'piece' },
  { id: 'opt-4x4-std', name: '4×4 Cement Standard (Rs. 30.00)', unitPrice: 30, coverage: 9.0, unitLabel: 'piece' },
  { id: 'opt-4x4-eco', name: '4×4 Cement Economy (Rs. 25.00)', unitPrice: 25, coverage: 9.0, unitLabel: 'piece' },
  { id: 'opt-4x4-red', name: '4×4 Red Terracotta (Rs. 40.00)', unitPrice: 40, coverage: 9.0, unitLabel: 'piece' },
  { id: 'opt-4x4-blk', name: '4×4 Charcoal Black (Rs. 42.00)', unitPrice: 42, coverage: 9.0, unitLabel: 'piece' },
  { id: 'opt-slab-12', name: '12×12 Slab Kata (Rs. 225.00)', unitPrice: 225, coverage: 1.0, unitLabel: 'slab' },
];

export const EstimatorSuite: React.FC<EstimatorSuiteProps> = ({ onAddToCart, showToast }) => {
  const [activeTab, setActiveTab] = useState<'area' | 'pinwheel' | 'transport'>('area');

  // --- TAB 1: AREA & BRICK STATE ---
  const [lengthFeet, setLengthFeet] = useState<number>(30);
  const [widthFeet, setWidthFeet] = useState<number>(15);
  const [sqftDirect, setSqftDirect] = useState<number>(450);
  const [selectedBrickId, setSelectedBrickId] = useState<string>('opt-8x4-std');
  const [includeWastage, setIncludeWastage] = useState<boolean>(true);

  // Helper for dimension input
  const handleDimensionChange = (newLen: number, newWid: number) => {
    setLengthFeet(newLen);
    setWidthFeet(newWid);
    setSqftDirect(Number((newLen * newWid).toFixed(1)));
  };

  const handleDirectSqftChange = (val: number) => {
    setSqftDirect(val);
  };

  const currentBrick = BRICK_OPTIONS.find((b) => b.id === selectedBrickId) || BRICK_OPTIONS[0];
  const areaBaseUnits = Math.ceil(sqftDirect * currentBrick.coverage);
  const areaWasteUnits = includeWastage ? Math.ceil(areaBaseUnits * 0.05) : 0;
  const areaTotalUnits = areaBaseUnits + areaWasteUnits;
  const areaTotalCost = areaTotalUnits * currentBrick.unitPrice;

  const handleAddAreaToCart = () => {
    if (areaTotalUnits <= 0) return;
    onAddToCart({
      id: `area-${currentBrick.id}-${Date.now()}`,
      name: `${currentBrick.name} (Calculated Lot: ${sqftDirect} sq.ft)`,
      unitPrice: currentBrick.unitPrice,
      unitLabel: currentBrick.unitLabel,
      qty: areaTotalUnits,
    });
    showToast(`Added ${areaTotalUnits.toLocaleString()} units of ${currentBrick.name} to cart.`);
  };

  // --- TAB 2: PINWHEEL MODULAR STATE ---
  const [pwSqft, setPwSqft] = useState<number>(350);
  const [pwCenterColor, setPwCenterColor] = useState<'black' | 'red'>('black');
  const [pwIncludeTransport, setPwIncludeTransport] = useState<boolean>(true);
  const [pwDistanceKm, setPwDistanceKm] = useState<number>(12);

  const pwCenterPrice = pwCenterColor === 'black' ? 42 : 40;
  const pwCenterName = pwCenterColor === 'black' ? 'Charcoal Black 4×4' : 'Terracotta Red 4×4';
  const pwCementPcs = Math.ceil(pwSqft * 4);
  const pwCenterPcs = Math.ceil(pwSqft * 1);
  const pwCementCost = pwCementPcs * 55;
  const pwCenterCost = pwCenterPcs * pwCenterPrice;
  const pwBricksSubtotal = pwCementCost + pwCenterCost;
  const pwRatePerSqft = 4 * 55 + pwCenterPrice; // 262 or 260

  const pwTransportCost = pwIncludeTransport
    ? pwDistanceKm <= 10
      ? 8500
      : 8500 + (pwDistanceKm - 10) * 300
    : 0;

  const pwGrandTotal = pwBricksSubtotal + pwTransportCost;

  const handleAddPinwheelToCart = () => {
    if (pwSqft <= 0) return;
    onAddToCart({
      id: `pw-cement-${Date.now()}`,
      name: `8×4 Cement Colour (Pinwheel Set Component - ${pwSqft} sqft)`,
      unitPrice: 55,
      unitLabel: 'piece',
      qty: pwCementPcs,
    });
    onAddToCart({
      id: `pw-accent-${Date.now()}`,
      name: `${pwCenterName} (Pinwheel Center Accent - ${pwSqft} sqft)`,
      unitPrice: pwCenterPrice,
      unitLabel: 'piece',
      qty: pwCenterPcs,
    });
    showToast(`Added Pinwheel components for ${pwSqft} sq.ft to cart.`);
  };

  const handleSendPinwheelWhatsApp = () => {
    const text =
      `*LAHIRU INTERLOCK - MALABE*\n` +
      `*Pinwheel Modular Quotation Request*\n` +
      `----------------------------------------\n` +
      `• Area Coverage: ${pwSqft} Sq. Ft\n` +
      `• 8×4 Cement Bricks: ${pwCementPcs.toLocaleString()} pcs (@ Rs. 55 = Rs. ${pwCementCost.toLocaleString()})\n` +
      `• 4×4 Center Accent: ${pwCenterPcs.toLocaleString()} pcs - ${pwCenterName} (@ Rs. ${pwCenterPrice} = Rs. ${pwCenterCost.toLocaleString()})\n` +
      `• Modular Bricks Subtotal: Rs. ${pwBricksSubtotal.toLocaleString()}\n` +
      (pwIncludeTransport
        ? `• Site Lorry Freight & Unloading (${pwDistanceKm} km): Rs. ${pwTransportCost.toLocaleString()}\n`
        : `• Transport: Yard Pickup (Ex-Factory Malabe)\n`) +
      `----------------------------------------\n` +
      `*Estimated Total: Rs. ${pwGrandTotal.toLocaleString()}*\n\n` +
      `Proprietor Lahiru Gamage, please confirm stock availability & dispatch dates.`;

    const url = `https://wa.me/94772050629?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // --- TAB 3: TRANSPORT MATRIX STATE ---
  const [transportKm, setTransportKm] = useState<number>(15);
  const extraKm = Math.max(0, transportKm - 10);
  const extraFee = extraKm * 300;
  const totalTransportFee = 8500 + extraFee;

  const handleAddTransportToCart = () => {
    onAddToCart({
      id: `tr-service-${Date.now()}`,
      name: `Lorry Transport & Site Manual Unloading (${transportKm} km from Malabe)`,
      unitPrice: totalTransportFee,
      unitLabel: 'trip',
      qty: 1,
    });
    showToast(`Added Lorry Transport (Rs. ${totalTransportFee.toLocaleString()}) to cart.`);
  };

  return (
    <section className="w-full py-12 px-4 lg:px-8 bg-white border-b border-slate-200" id="estimation-suite">
      <div className="max-w-[1280px] mx-auto space-y-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-[11px] font-bold text-[#0051d5] uppercase tracking-widest">
              Engineering Estimators
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#000922] font-display tracking-tight mt-1">
              Interactive Brick, Pattern &amp; Transport Estimator
            </h2>
            <p className="text-sm text-slate-600 mt-1 max-w-3xl">
              Compute exact unit requirements with waste factors, analyze modular Pinwheel layout combos, or calculate lorry freight charges to your exact site.
            </p>
          </div>

          {/* Tab Switcher */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1.5 rounded-xl border border-slate-200 self-start md:self-auto overflow-x-auto max-w-full">
            <button
              type="button"
              onClick={() => setActiveTab('area')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'area'
                  ? 'bg-[#000922] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              📐 Area &amp; Brick
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('pinwheel')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'pinwheel'
                  ? 'bg-[#000922] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              🌟 Pinwheel Modular
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('transport')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'transport'
                  ? 'bg-[#000922] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              🚚 Transport Matrix
            </button>
          </div>
        </div>

        {/* TAB 1: AREA & BRICK */}
        {activeTab === 'area' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 bg-[#eff4ff] p-6 lg:p-8 rounded-2xl border border-blue-100">
            {/* Input Form (7 Cols) */}
            <div className="lg:col-span-7 space-y-5">
              <div className="space-y-1">
                <h3 className="text-xl font-bold text-[#000922] font-display">
                  Driveway or Walkway Area Input
                </h3>
                <p className="text-xs text-slate-600">
                  Enter dimensions in linear feet or directly type your known square footage below.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Length (Feet)
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    value={lengthFeet}
                    onChange={(e) => handleDimensionChange(parseFloat(e.target.value) || 0, widthFeet)}
                    className="w-full px-4 py-2.5 rounded-lg bg-white text-[#000922] font-bold text-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5] shadow-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Width (Feet)
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    value={widthFeet}
                    onChange={(e) => handleDimensionChange(lengthFeet, parseFloat(e.target.value) || 0)}
                    className="w-full px-4 py-2.5 rounded-lg bg-white text-[#000922] font-bold text-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5] shadow-xs"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-700">
                    Or Enter Direct Total Area (Sq. Ft)
                  </label>
                  <span className="text-[10px] font-bold text-[#0051d5] bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                    Auto-synced
                  </span>
                </div>
                <input
                  type="number"
                  min="1"
                  step="any"
                  value={sqftDirect}
                  onChange={(e) => handleDirectSqftChange(parseFloat(e.target.value) || 0)}
                  className="w-full px-4 py-2.5 rounded-lg bg-white text-[#000922] font-bold text-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5] shadow-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Select Brick / Tile Variety
                </label>
                <select
                  value={selectedBrickId}
                  onChange={(e) => setSelectedBrickId(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg bg-white text-[#000922] text-sm font-semibold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5] shadow-xs cursor-pointer"
                >
                  {BRICK_OPTIONS.map((opt) => (
                    <option key={opt.id} value={opt.id}>
                      {opt.name} — {opt.coverage} pcs / sqft
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-lg bg-white border border-slate-200 shadow-xs">
                <input
                  type="checkbox"
                  id="calc-wastage"
                  checked={includeWastage}
                  onChange={(e) => setIncludeWastage(e.target.checked)}
                  className="w-4 h-4 rounded text-[#0051d5] focus:ring-[#0051d5] cursor-pointer"
                />
                <label htmlFor="calc-wastage" className="text-xs text-slate-700 cursor-pointer select-none">
                  Include recommended{' '}
                  <strong className="text-[#000922] font-bold">+5% cutting &amp; perimeter wastage allowance</strong>
                </label>
              </div>
            </div>

            {/* Output Card (5 Cols) */}
            <div className="lg:col-span-5 flex flex-col justify-between bg-white p-6 rounded-xl shadow-md border border-slate-200 space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Calculated Scope
                  </span>
                  <span className="text-[10px] font-bold bg-blue-100 text-[#0051d5] px-2.5 py-0.5 rounded-md">
                    Standard Layout
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                    <p className="text-xs text-slate-500 font-medium">Net Surface Area</p>
                    <p className="text-xl font-extrabold text-[#000922] font-display mt-0.5">
                      {sqftDirect.toFixed(1)} sq.ft
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                    <p className="text-xs text-slate-500 font-medium">Coverage Factor</p>
                    <p className="text-xl font-extrabold text-[#0051d5] font-display mt-0.5">
                      {currentBrick.coverage} pcs/sqft
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#000922] text-white space-y-1 shadow-xs">
                  <p className="text-[11px] text-blue-300 uppercase font-semibold tracking-wider">
                    Recommended Quantity
                  </p>
                  <div className="flex items-baseline justify-between">
                    <p className="text-4xl font-extrabold text-white font-display leading-none">
                      {areaTotalUnits.toLocaleString()}
                    </p>
                    <span className="text-sm font-bold text-blue-200">
                      {currentBrick.unitLabel === 'slab' ? 'Slabs' : 'Pieces'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 pt-1">
                    {includeWastage
                      ? `Includes ${areaWasteUnits.toLocaleString()} units (+5%) cutting reserve.`
                      : 'Exact net piece requirement without wastage buffer.'}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-sm font-semibold text-slate-700">Material Estimated Total</span>
                  <span className="text-2xl font-extrabold text-[#000922] font-display">
                    Rs. {areaTotalCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleAddAreaToCart}
                  className="w-full py-3 px-4 rounded-xl bg-[#0051d5] text-white font-bold text-sm hover:bg-[#003ea8] transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>Add Calculated Quantity to Cart</span>
                </button>
                <p className="text-[10px] text-center text-slate-400">
                  Quantities can be fine-tuned directly in your cart anytime.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PINWHEEL MODULAR */}
        {activeTab === 'pinwheel' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 bg-[#eff4ff] p-6 lg:p-8 rounded-2xl border border-blue-100">
            {/* Pinwheel Inputs (7 Cols) */}
            <div className="lg:col-span-7 space-y-5">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-yellow-500 font-bold text-lg">★</span>
                  <h3 className="text-xl font-bold text-[#000922] font-display">
                    Pinwheel Architectural Modular System
                  </h3>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  The Pinwheel pattern arranges 4 elongated 8×4 blocks in a spiral pinwheel formation orbiting a singular 4×4 focal accent center brick. Every 1.0 Sq. Ft pattern cell contains exactly:
                </p>
              </div>

              {/* Formula Pill Graphic */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
                  <div className="w-7 h-7 mx-auto rounded-full bg-slate-100 flex items-center justify-center font-bold text-[#000922] mb-1 text-xs">
                    4
                  </div>
                  <p className="text-xs font-bold text-[#000922]">8×4 Cement Bricks</p>
                  <p className="text-[11px] text-slate-500">@ Rs. 55 = Rs. 220</p>
                </div>
                <div className="flex items-center justify-center text-[#0051d5] font-bold text-xl">
                  +
                </div>
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
                  <div className="w-7 h-7 mx-auto rounded-full bg-blue-100 flex items-center justify-center font-bold text-[#0051d5] mb-1 text-xs">
                    1
                  </div>
                  <p className="text-xs font-bold text-[#000922]">4×4 Center Accent</p>
                  <p className="text-[11px] text-slate-500">
                    @ Rs. {pwCenterPrice} ({pwCenterColor === 'black' ? 'Black' : 'Red'})
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Paving Area (Sq. Ft)
                  </label>
                  <input
                    type="number"
                    min="10"
                    step="any"
                    value={pwSqft}
                    onChange={(e) => setPwSqft(parseFloat(e.target.value) || 0)}
                    className="w-full px-4 py-2.5 rounded-lg bg-white text-[#000922] font-bold text-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5] shadow-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Center Accent Brick Color
                  </label>
                  <select
                    value={pwCenterColor}
                    onChange={(e) => setPwCenterColor(e.target.value as 'black' | 'red')}
                    className="w-full px-4 py-2.5 rounded-lg bg-white text-[#000922] text-sm font-semibold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5] shadow-xs cursor-pointer"
                  >
                    <option value="black">Architectural Charcoal Black (Rs. 262 / sqft)</option>
                    <option value="red">Terracotta Red (Rs. 260 / sqft)</option>
                  </select>
                </div>
              </div>

              {/* Distance & Transport Toggle */}
              <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <label htmlFor="pw-transport-toggle" className="text-xs font-bold text-[#000922] cursor-pointer">
                    Include Factory Heavy Lorry Transport?
                  </label>
                  <input
                    type="checkbox"
                    id="pw-transport-toggle"
                    checked={pwIncludeTransport}
                    onChange={(e) => setPwIncludeTransport(e.target.checked)}
                    className="w-4 h-4 rounded text-[#0051d5] focus:ring-[#0051d5] cursor-pointer"
                  />
                </div>

                {pwIncludeTransport && (
                  <div className="space-y-2 pt-1 border-t border-slate-100">
                    <div className="flex items-center justify-between text-xs text-slate-600">
                      <span>Distance from Malabe Factory Yard:</span>
                      <span className="font-bold text-[#000922] text-sm">{pwDistanceKm} km</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="50"
                      value={pwDistanceKm}
                      onChange={(e) => setPwDistanceKm(parseInt(e.target.value) || 1)}
                      className="w-full accent-[#0051d5] cursor-pointer"
                    />
                    <p className="text-[11px] text-slate-400">
                      Includes hand offloading at driveway or compound edge by lorry crew.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Pinwheel Breakdown Output (5 Cols) */}
            <div className="lg:col-span-5 flex flex-col justify-between bg-white p-6 rounded-xl shadow-md border border-slate-200 space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Detailed Breakdown
                  </span>
                  <span className="text-[11px] font-bold bg-[#0051d5] text-white px-2.5 py-0.5 rounded-md">
                    Rs. {pwRatePerSqft} / sq.ft
                  </span>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                    <span className="text-slate-600">
                      8×4 Cement Bricks (<strong className="text-[#000922]">{pwCementPcs.toLocaleString()}</strong> pcs @ Rs. 55):
                    </span>
                    <span className="font-bold text-[#000922]">Rs. {pwCementCost.toLocaleString()}.00</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                    <span className="text-slate-600">
                      Center Accent Bricks (<strong className="text-[#000922]">{pwCenterPcs.toLocaleString()}</strong> pcs):
                    </span>
                    <span className="font-bold text-[#000922]">Rs. {pwCenterCost.toLocaleString()}.00</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                    <span className="text-slate-600">Modular Bricks Subtotal:</span>
                    <span className="font-bold text-[#000922]">Rs. {pwBricksSubtotal.toLocaleString()}.00</span>
                  </div>
                  {pwIncludeTransport && (
                    <div className="flex items-center justify-between p-2.5 bg-blue-50 text-[#0051d5] rounded-lg border border-blue-100">
                      <span>Site Lorry Freight ({pwDistanceKm} km):</span>
                      <span className="font-bold">Rs. {pwTransportCost.toLocaleString()}.00</span>
                    </div>
                  )}
                </div>

                <div className="p-4 rounded-xl bg-[#000922] text-white space-y-1 shadow-xs">
                  <p className="text-[11px] uppercase text-blue-300 font-semibold tracking-wider">
                    Estimated Investment
                  </p>
                  <p className="text-3xl sm:text-4xl font-extrabold text-white font-display leading-tight">
                    Rs. {pwGrandTotal.toLocaleString()}.00
                  </p>
                  <p className="text-[11px] text-slate-300">
                    Price valid for Malabe factory dispatch direct to site.
                  </p>
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleSendPinwheelWhatsApp}
                  className="w-full py-3 px-4 rounded-xl bg-[#16a34a] text-white font-bold text-sm hover:bg-[#15803d] transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Send Pinwheel Quotation via WhatsApp</span>
                </button>
                <button
                  type="button"
                  onClick={handleAddPinwheelToCart}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#000922] font-semibold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShoppingCart className="w-3.5 h-3.5" />
                  <span>Add Pinwheel Component Lots to Cart</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: TRANSPORT MATRIX */}
        {activeTab === 'transport' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 bg-[#eff4ff] p-6 lg:p-8 rounded-2xl border border-blue-100">
            {/* Transport Input Form (7 Cols) */}
            <div className="lg:col-span-7 space-y-5">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-[#0051d5]">
                  <Truck className="w-5 h-5" />
                  <h3 className="text-xl font-bold text-[#000922] font-display">
                    Heavy Truck Freight &amp; Site Manual Unloading
                  </h3>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Every transport dispatched from our Malabe yard includes factory heavy lorry haulage plus experienced labor personnel to unload bricks directly beside your unloading bay.
                </p>
              </div>

              {/* Rate Card */}
              <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-2">
                <h4 className="text-xs font-bold text-[#0051d5] uppercase tracking-wider">
                  Official Transport Rate Formula
                </h4>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex-1">
                    <span className="text-sm font-bold text-[#000922]">Base Rate: Rs. 8,500.00</span>
                    <span className="block text-[11px] text-slate-500 mt-0.5">
                      Covers up to first 10 km from Malabe yard
                    </span>
                  </div>
                  <span className="text-xl font-bold text-slate-400 hidden sm:inline">+</span>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex-1">
                    <span className="text-sm font-bold text-[#000922]">Rs. 300.00 per km</span>
                    <span className="block text-[11px] text-slate-500 mt-0.5">
                      Applicable for every km beyond 10 km
                    </span>
                  </div>
                </div>
              </div>

              {/* Presets */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Quick Destination Presets
                </label>
                <div className="flex flex-wrap gap-2">
                  {[
                    { km: 5, label: '5 km (Rs. 8,500)' },
                    { km: 10, label: '10 km (Rs. 8,500)' },
                    { km: 15, label: '15 km (Rs. 10,000)' },
                    { km: 20, label: '20 km (Rs. 11,500)' },
                    { km: 30, label: '30 km (Rs. 14,500)' },
                  ].map((p) => (
                    <button
                      key={p.km}
                      type="button"
                      onClick={() => setTransportKm(p.km)}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all border cursor-pointer ${
                        transportKm === p.km
                          ? 'bg-[#0051d5] text-white border-[#0051d5] shadow-xs'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Input */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Custom Road Distance from Malabe Yard (KM)
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    min="1"
                    max="150"
                    value={transportKm}
                    onChange={(e) => setTransportKm(Math.max(1, parseFloat(e.target.value) || 1))}
                    className="w-full px-4 py-2.5 rounded-lg bg-white text-[#000922] font-bold text-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5] shadow-xs"
                  />
                  <span className="text-sm font-semibold text-slate-600 whitespace-nowrap">
                    Kilometers
                  </span>
                </div>
              </div>
            </div>

            {/* Output Freight Box (5 Cols) */}
            <div className="lg:col-span-5 flex flex-col justify-between bg-white p-6 rounded-xl shadow-md border border-slate-200 space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <span className="text-xs font-bold text-[#000922] uppercase tracking-wider">
                    Transport Quote Summary
                  </span>
                  <span className="text-[10px] font-bold bg-[#16a34a] text-white px-2.5 py-0.5 rounded-md">
                    Unloading Staff Included
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Base Rate (1-10 km):</span>
                    <span className="font-bold text-[#000922]">Rs. 8,500.00</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">
                      Extra Distance Surcharge ({extraKm} km @ Rs. 300):
                    </span>
                    <span className="font-bold text-[#000922]">Rs. {extraFee.toLocaleString()}.00</span>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-sm">
                    <span className="font-semibold text-slate-800">Total Transport Cost:</span>
                    <span className="text-xl font-extrabold text-[#0051d5] font-display">
                      Rs. {totalTransportFee.toLocaleString()}.00
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-lg bg-blue-50 text-slate-700 text-xs border border-blue-100 leading-relaxed">
                  <strong className="text-[#000922]">Important Logistics Note:</strong> Please ensure lorry access width of at least 10 feet into the premises. Our team carefully stacks pavers by hand to minimize chipped edges.
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleAddTransportToCart}
                  className="w-full py-3 px-4 rounded-xl bg-[#000922] text-white font-bold text-sm hover:bg-[#0f2042] transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Truck className="w-4 h-4 text-blue-400" />
                  <span>Add Transport &amp; Unloading to Cart</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
