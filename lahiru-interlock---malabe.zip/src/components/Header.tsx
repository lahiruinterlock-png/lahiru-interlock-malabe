import React from 'react';
import { Phone, MapPin, User, ExternalLink, ShoppingBag, MessageSquare } from 'lucide-react';

interface HeaderProps {
  cartItemCount: number;
  onOpenCart: () => void;
  onSelectCategory: (category: string) => void;
  onScrollToEstimators: () => void;
  activeCategory: string;
}

export const Header: React.FC<HeaderProps> = ({
  cartItemCount,
  onOpenCart,
  onSelectCategory,
  onScrollToEstimators,
  activeCategory,
}) => {
  return (
    <header className="sticky top-0 left-0 right-0 z-50 shadow-md">
      {/* Top Utility Bar */}
      <div className="bg-[#000922] text-white py-1.5 px-4 lg:px-8 border-b border-white/10">
        <div className="max-w-[1280px] mx-auto flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="flex items-center gap-1.5 text-slate-300">
              <MapPin className="w-3.5 h-3.5 text-blue-400" />
              <span>1074/03, Amaragoda road, pothu arawa, Malabe</span>
            </span>
            <span className="hidden md:inline text-slate-500">|</span>
            <span className="hidden md:flex items-center gap-1.5 text-slate-300">
              <User className="w-3.5 h-3.5 text-blue-400" />
              <span>Proprietor: Lahiru Gamage</span>
            </span>
            <a
              href="https://maps.google.com/?q=1074/03+Amaragoda+road+pothu+arawa+Malabe"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-1 text-blue-300 hover:text-white hover:underline transition-colors"
            >
              <span>Open in Google Maps</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="flex items-center gap-4">
            <a
              href="tel:0772050629"
              className="flex items-center gap-1.5 font-bold text-white hover:text-blue-300 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>0772050629</span>
            </a>
            <div className="w-7 h-7 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 border border-slate-700">
              <User className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="h-20 max-w-[1280px] mx-auto px-4 lg:px-8 flex items-center justify-between gap-4">
          {/* Logo & Yard Title */}
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-3 shrink-0 group"
          >
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCcNzKeLJZ0xznS39EK8Ohl8BTrWE_fXcohJgio9kP5ro9ja6-S2-u8ECQG_J7KcClz6Mrwkfy6n1O4eQuhJtIMpNoJyJaDdq9GDPQKhlIYMXMVH4G3t_gUVixwsAPsbF08r9avJ_ZNhPfkUDTWe4ruwejE-K-ISJvKFEYDHbmKvwtQvcQPFOFXtGJw1M3HoVzj_UlOMgVSQ69pVjYLM4nMS4ZywZkDKprqiZbIZogIZsQgl7xOEUP9Wg"
              alt="Lahiru Interlock Logo"
              className="h-10 w-auto object-contain transition-transform group-hover:scale-105"
            />
            <div className="flex flex-col">
              <span className="font-extrabold text-lg text-[#000922] tracking-tight uppercase leading-none font-display">
                Lahiru Interlock
              </span>
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">
                Malabe Factory &amp; Yard
              </span>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-1 text-xs font-semibold">
            <button
              onClick={() => onSelectCategory('all')}
              className={`px-3 py-2 rounded-lg transition-colors ${
                activeCategory === 'all'
                  ? 'bg-[#0f2042] text-white font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              All Products
            </button>
            <button
              onClick={() => onSelectCategory('modular')}
              className={`px-3 py-2 rounded-lg transition-colors ${
                activeCategory === 'modular'
                  ? 'bg-[#0f2042] text-white font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              🌟 Modular Patterns
            </button>
            <button
              onClick={() => onSelectCategory('8x4')}
              className={`px-3 py-2 rounded-lg transition-colors ${
                activeCategory === '8x4'
                  ? 'bg-[#0f2042] text-white font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              8×4 Bricks
            </button>
            <button
              onClick={() => onSelectCategory('4x4')}
              className={`px-3 py-2 rounded-lg transition-colors ${
                activeCategory === '4x4'
                  ? 'bg-[#0f2042] text-white font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              4×4 Bricks
            </button>
            <button
              onClick={() => onSelectCategory('slabs')}
              className={`px-3 py-2 rounded-lg transition-colors ${
                activeCategory === 'slabs'
                  ? 'bg-[#0f2042] text-white font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Slabs &amp; Silpara
            </button>
            <button
              onClick={() => onSelectCategory('kerbs')}
              className={`px-3 py-2 rounded-lg transition-colors ${
                activeCategory === 'kerbs'
                  ? 'bg-[#0f2042] text-white font-bold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Kerbs &amp; Transport
            </button>
            <button
              onClick={onScrollToEstimators}
              className="px-3 py-2 rounded-lg text-blue-600 hover:text-blue-700 hover:bg-blue-50 font-bold transition-colors"
            >
              Calculators
            </button>
          </nav>

          {/* Direct CTA Buttons */}
          <div className="flex items-center gap-2.5 shrink-0">
            <a
              href="tel:0772050629"
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors shadow-xs"
            >
              <Phone className="w-3.5 h-3.5 text-blue-600" />
              <span>Call</span>
            </a>
            <a
              href="https://wa.me/94772050629?text=Hello%20Lahiru%20Gamage,%20I%20am%20inquiring%20about%20paving%20stones%20from%20your%20Malabe%20yard."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#16a34a] hover:bg-[#15803d] text-white text-xs font-semibold transition-all shadow-sm active:scale-95"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">WhatsApp Order</span>
              <span className="lg:hidden">WhatsApp</span>
            </a>
            <button
              type="button"
              onClick={onOpenCart}
              aria-label="View Cart"
              className="relative inline-flex items-center justify-center p-2.5 rounded-lg bg-[#000922] text-white hover:bg-[#0f2042] transition-colors active:scale-95 shadow-sm"
            >
              <ShoppingBag className="w-4 h-4" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#0051d5] text-white text-[10px] font-bold flex items-center justify-center shadow-xs animate-pulse">
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Announcement Ribbon */}
      <div className="bg-[#e5eeff] text-[#000922] py-2 px-4 border-b border-blue-200/50">
        <div className="max-w-[1280px] mx-auto flex items-center justify-center gap-2 text-center text-xs font-medium">
          <span className="text-[#0051d5] font-bold">✓</span>
          <span>
            <strong>Factory-Direct Heavy Duty Paving Stones</strong> • Delivery with On-site Manual Unloading Available Across Western Province
          </span>
        </div>
      </div>
    </header>
  );
};
