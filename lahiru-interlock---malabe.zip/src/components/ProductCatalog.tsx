import React, { useState } from 'react';
import { ShoppingCart, Search, ArrowUpDown } from 'lucide-react';
import { Product, PRODUCTS } from '../data/products';
import { CartItem } from '../types';

interface ProductCatalogProps {
  activeCategory: string;
  onSelectCategory: (category: string) => void;
  onAddToCart: (item: CartItem) => void;
  showToast: (msg: string) => void;
}

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  activeCategory,
  onSelectCategory,
  onAddToCart,
  showToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'default' | 'price-asc' | 'price-desc'>('default');

  // Local state for product quantities
  const [itemQuantities, setItemQuantities] = useState<Record<string, number>>(() => {
    const init: Record<string, number> = {};
    PRODUCTS.forEach((p) => {
      init[p.id] = p.defaultQty;
    });
    return init;
  });

  const handleStepQty = (id: string, step: number) => {
    setItemQuantities((prev) => {
      const current = prev[id] || 1;
      const updated = Math.max(1, current + step);
      return { ...prev, [id]: updated };
    });
  };

  const handleSetQty = (id: string, val: number) => {
    setItemQuantities((prev) => ({
      ...prev,
      [id]: Math.max(1, val),
    }));
  };

  const handleAddDirect = (product: Product) => {
    const qty = itemQuantities[product.id] || product.defaultQty;
    onAddToCart({
      id: product.id,
      name: product.name,
      unitPrice: product.unitPrice,
      unitLabel: product.unitLabel,
      qty,
      image: product.image,
    });
    showToast(`Added ${qty.toLocaleString()} ${product.unitLabel}s of ${product.name} to cart.`);
  };

  // Filter & sort products
  const filteredProducts = PRODUCTS.filter((p) => {
    const matchesCat = activeCategory === 'all' || p.category === activeCategory;
    const matchesQuery =
      searchQuery.trim() === '' ||
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  }).sort((a, b) => {
    if (sortBy === 'price-asc') return a.unitPrice - b.unitPrice;
    if (sortBy === 'price-desc') return b.unitPrice - a.unitPrice;
    return 0;
  });

  return (
    <section className="w-full py-12 px-4 lg:px-8 bg-[#eff4ff] border-b border-blue-100" id="product-catalog">
      <div className="max-w-[1280px] mx-auto space-y-8">
        {/* Catalog Heading & Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-[11px] font-bold text-[#0051d5] uppercase tracking-widest">
              Inventory &amp; Pricing
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#000922] font-display tracking-tight mt-1">
              Lahiru Interlock Product Catalog
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              All prices in Sri Lankan Rupees (LKR). Direct from Malabe plant.
            </p>
          </div>

          {/* Search & Sort Controls */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search pavers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-lg bg-white text-xs border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5] shadow-xs w-44 sm:w-56"
              />
            </div>
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="pl-3 pr-7 py-1.5 rounded-lg bg-white text-xs font-semibold text-slate-700 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5] shadow-xs cursor-pointer appearance-none"
              >
                <option value="default">Sort: Default</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
              <ArrowUpDown className="w-3 h-3 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <button
            type="button"
            onClick={() => onSelectCategory('all')}
            className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeCategory === 'all'
                ? 'bg-[#000922] text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            All Products (15)
          </button>
          <button
            type="button"
            onClick={() => onSelectCategory('modular')}
            className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeCategory === 'modular'
                ? 'bg-[#000922] text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            🌟 Modular Patterns (2)
          </button>
          <button
            type="button"
            onClick={() => onSelectCategory('8x4')}
            className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeCategory === '8x4'
                ? 'bg-[#000922] text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            8×4 Bricks (4)
          </button>
          <button
            type="button"
            onClick={() => onSelectCategory('4x4')}
            className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeCategory === '4x4'
                ? 'bg-[#000922] text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            4×4 Bricks (4)
          </button>
          <button
            type="button"
            onClick={() => onSelectCategory('slabs')}
            className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeCategory === 'slabs'
                ? 'bg-[#000922] text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            Slabs &amp; Silpara (3)
          </button>
          <button
            type="button"
            onClick={() => onSelectCategory('kerbs')}
            className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeCategory === 'kerbs'
                ? 'bg-[#000922] text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            Kerbs &amp; Transport (2)
          </button>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => {
            const currentQty = itemQuantities[product.id] || product.defaultQty;
            const isModular = product.category === 'modular';

            return (
              <div
                key={product.id}
                className={`bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between border ${
                  isModular ? 'border-[#0051d5]/40 ring-1 ring-[#0051d5]/20' : 'border-slate-200/80'
                }`}
              >
                <div className="space-y-3">
                  {/* Image & Badge */}
                  <div className="relative rounded-xl overflow-hidden aspect-[4/3] bg-slate-100 group">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      loading="lazy"
                    />
                    <span
                      className={`absolute top-2.5 left-2.5 px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wider shadow-xs ${
                        product.badgeColor || 'bg-[#000922] text-white'
                      }`}
                    >
                      {product.badge}
                    </span>
                  </div>

                  {/* Info Header */}
                  <div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                        {product.specLabel}
                      </span>
                      <span className="text-xs text-[#0051d5] font-semibold">
                        {product.coverageLabel}
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-[#000922] font-display mt-0.5 leading-snug">
                      {product.name}
                    </h3>
                    <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                      {product.description}
                    </p>
                  </div>

                  {/* Pricing row */}
                  <div className="flex items-baseline justify-between pt-1 border-t border-slate-100">
                    <div>
                      <span className="text-xl font-extrabold text-[#000922] font-display">
                        Rs. {product.unitPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>
                      <span className="text-xs text-slate-500 ml-1">/ {product.unitLabel}</span>
                    </div>
                    {product.approxSqftPrice && (
                      <span className="text-xs text-slate-400 font-medium">
                        {product.approxSqftPrice}
                      </span>
                    )}
                  </div>
                </div>

                {/* Controls & Add to Cart */}
                <div className="space-y-2.5 pt-4 mt-2">
                  {/* Quantity Stepper (if not single transport unit) */}
                  {product.category !== 'kerbs' || product.id !== 'p15' ? (
                    <>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleStepQty(product.id, -product.stepQty)}
                          className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#000922] font-bold transition-colors flex items-center justify-center cursor-pointer text-base"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          min="1"
                          value={currentQty}
                          onChange={(e) => handleSetQty(product.id, parseInt(e.target.value) || 1)}
                          className="w-full py-1.5 text-center font-bold text-base text-[#000922] bg-slate-50 rounded-lg border border-slate-200 focus:outline-none focus:ring-1 focus:ring-[#0051d5]"
                        />
                        <button
                          type="button"
                          onClick={() => handleStepQty(product.id, product.stepQty)}
                          className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#000922] font-bold transition-colors flex items-center justify-center cursor-pointer text-base"
                        >
                          +
                        </button>
                      </div>

                      {/* Quick Chips */}
                      <div className="flex gap-1.5 justify-center">
                        {product.chips.map((chip) => (
                          <button
                            key={chip}
                            type="button"
                            onClick={() => handleSetQty(product.id, chip)}
                            className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-[11px] font-bold text-slate-600 transition-colors cursor-pointer"
                          >
                            +{chip}
                          </button>
                        ))}
                      </div>
                    </>
                  ) : (
                    <div className="p-2 rounded-lg bg-slate-50 text-center text-xs text-slate-600 border border-slate-100">
                      Standard delivery unit (1 lorry load up to 2,500 pcs)
                    </div>
                  )}

                  {/* Add to order button */}
                  <button
                    type="button"
                    onClick={() => handleAddDirect(product)}
                    className={`w-full py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95 cursor-pointer ${
                      isModular
                        ? 'bg-[#0051d5] text-white hover:bg-[#003ea8]'
                        : 'bg-[#000922] text-white hover:bg-[#0f2042]'
                    }`}
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    <span>
                      {isModular
                        ? 'Add Sets to Order'
                        : product.id === 'p15'
                        ? 'Add Lorry Transport'
                        : 'Add to Order'}
                    </span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
