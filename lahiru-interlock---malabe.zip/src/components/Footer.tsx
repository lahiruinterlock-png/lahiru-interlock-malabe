import React from 'react';
import { MapPin, Navigation, Clock, CreditCard, Phone } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full bg-[#000922] text-white pt-12 pb-24 border-t border-slate-800">
      <div className="max-w-[1280px] mx-auto px-4 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
          {/* Brand Info */}
          <div className="space-y-4">
            <div>
              <span className="font-extrabold text-xl text-white font-display tracking-tight uppercase">
                Lahiru Interlock
              </span>
              <p className="text-[11px] text-blue-300 font-bold uppercase tracking-wider mt-0.5">
                Malabe Factory &amp; Yard
              </p>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Sri Lanka’s standard-tested interlock paver production facility in Malabe. Engineering high-load driveway stones, garden tiles, and custom modular solutions.
            </p>
            <div className="pt-1 space-y-1.5 text-xs text-slate-300">
              <p>
                <strong className="text-white">Proprietor:</strong> Lahiru Gamage
              </p>
              <p className="flex items-center gap-1.5">
                <strong className="text-white">Hotline:</strong>
                <a href="tel:0772050629" className="text-blue-300 font-bold hover:underline">
                  0772050629
                </a>
              </p>
            </div>
          </div>

          {/* Location */}
          <div className="space-y-4">
            <h3 className="font-bold text-sm text-white font-display uppercase tracking-wider">
              Factory &amp; Yard Location
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed flex items-start gap-2">
              <MapPin className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <span>
                1074/03, Amaragoda road,<br />
                pothu arawa, Malabe,<br />
                Sri Lanka.
              </span>
            </p>
            <div className="pt-1">
              <a
                href="https://maps.google.com/?q=1074/03+Amaragoda+road+pothu+arawa+Malabe"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#0f2042] text-white hover:bg-blue-600 transition-colors text-xs font-semibold border border-blue-900/50"
              >
                <Navigation className="w-3.5 h-3.5 text-blue-400" />
                <span>Get Google Map Directions</span>
              </a>
            </div>
          </div>

          {/* Business Hours */}
          <div className="space-y-4">
            <h3 className="font-bold text-sm text-white font-display uppercase tracking-wider flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-400" />
              <span>Business Hours &amp; Dispatch</span>
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              <li>
                <strong className="text-white">Mon – Sat:</strong> 7:30 AM – 6:30 PM
              </li>
              <li>
                <strong className="text-white">Sunday:</strong> 8:00 AM – 2:00 PM
              </li>
              <li className="pt-1 text-[11px] text-blue-200">
                <strong className="text-white">Dispatch:</strong> Same-day Colombo, Kaduwela, Malabe, Athurugiriya &amp; Gampaha
              </li>
            </ul>
          </div>

          {/* Bank Transfer */}
          <div className="space-y-4">
            <h3 className="font-bold text-sm text-white font-display uppercase tracking-wider flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-400" />
              <span>Direct Bank Transfer Info</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Advance orders and site delivery reservations can be secured through official BOC / Commercial Bank transfers. Invoices with lorry gate passes issued on dispatch.
            </p>
            <div className="p-3 rounded-lg bg-[#0f2042] text-xs text-blue-200 border border-blue-900/40 space-y-1">
              <p>
                <strong className="text-white">Reference:</strong> Use Order ID &amp; Phone
              </p>
              <p>
                <strong className="text-white">WhatsApp Slip:</strong> 0772050629
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <p>© 2025 Lahiru Interlock - Malabe. All Rights Reserved.</p>
          <p className="text-slate-400 font-medium">
            Manufactured with SLS Compliant Aggregates &gt; 45 N/mm²
          </p>
        </div>
      </div>
    </footer>
  );
};
