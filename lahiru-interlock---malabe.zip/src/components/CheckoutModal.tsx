import React, { useState } from 'react';
import { X, MessageSquare, Trash2, Send, Plus, Minus } from 'lucide-react';
import { CartItem } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQty: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQty,
  onRemoveItem,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryTown, setDeliveryTown] = useState('');
  const [distanceKm, setDistanceKm] = useState<number>(10);
  const [includeTransport, setIncludeTransport] = useState<boolean>(true);
  const [siteNotes, setSiteNotes] = useState('');

  if (!isOpen) return null;

  // Calculate Materials Total
  const materialsTotal = items.reduce((acc, it) => acc + it.qty * it.unitPrice, 0);

  // Calculate Transport Fee
  const extraKm = Math.max(0, distanceKm - 10);
  const transportFee = includeTransport ? 8500 + extraKm * 300 : 0;

  // Grand Total
  const grandTotal = materialsTotal + transportFee;

  // Format WhatsApp message
  const generateWhatsAppMessage = () => {
    const name = customerName.trim() || '[Customer Name]';
    const phone = customerPhone.trim() || '[Phone Number]';
    const town = deliveryTown.trim() || '[Delivery Town / Area]';

    let itemsText = '';
    if (items.length === 0) {
      itemsText = '• (No specific items chosen - general quotation inquiry)\n';
    } else {
      items.forEach((it) => {
        itemsText += `• ${it.name}: ${it.qty.toLocaleString()} ${it.unitLabel}s = Rs. ${(it.qty * it.unitPrice).toLocaleString()}\n`;
      });
    }

    let msg =
      `*LAHIRU INTERLOCK - MALABE (ORDER INQUIRY)*\n` +
      `----------------------------------------\n` +
      `*Customer Details:*\n` +
      `• Name: ${name}\n` +
      `• Contact: ${phone}\n` +
      `• Delivery Location: ${town} (~${distanceKm} km from Malabe)\n` +
      `----------------------------------------\n` +
      `*Order Items:*\n` +
      `${itemsText}` +
      `• Materials Subtotal: Rs. ${materialsTotal.toLocaleString()}\n`;

    if (includeTransport) {
      msg += `• Lorry Haulage & Site Unloading: Rs. ${transportFee.toLocaleString()} (${distanceKm} km)\n`;
    } else {
      msg += `• Transport: Client yard self-pickup (Ex-Factory Malabe)\n`;
    }

    msg +=
      `----------------------------------------\n` +
      `*Estimated Quotation Sum: Rs. ${grandTotal.toLocaleString()}*\n`;

    if (siteNotes.trim()) {
      msg += `• Site Notes: ${siteNotes.trim()}\n`;
    }

    msg += `\nProprietor Lahiru Gamage, please verify this order and send bank transfer instructions or lorry dispatch confirmation.`;

    return msg;
  };

  const handleLaunchWhatsApp = () => {
    const text = generateWhatsAppMessage();
    const url = `https://wa.me/94772050629?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#000922]/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="bg-[#000922] text-white px-5 sm:px-6 py-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#16a34a] flex items-center justify-center text-white shadow-xs">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white font-display">
                Finalize Order &amp; WhatsApp Lahiru
              </h3>
              <p className="text-[11px] text-blue-200">
                Direct Malabe Yard Order Confirmation
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-xs">
          {/* Items Summary Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between pb-1 border-b border-slate-100">
              <span className="font-bold text-[#000922] uppercase tracking-wider">
                Selected Order Line Items
              </span>
              <span className="text-slate-500 font-medium">
                {items.length} {items.length === 1 ? 'item' : 'items'}
              </span>
            </div>

            <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
              {items.length === 0 ? (
                <div className="p-4 bg-slate-50 rounded-xl text-center text-slate-500 border border-slate-200/60">
                  No items in cart yet. Add paving blocks or use the calculator above!
                </div>
              ) : (
                items.map((it) => (
                  <div
                    key={it.id}
                    className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-100 gap-3"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-[#000922] truncate text-xs">{it.name}</p>
                      <p className="text-[11px] text-slate-500">
                        {it.qty.toLocaleString()} {it.unitLabel}s × Rs. {it.unitPrice.toLocaleString()}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-0.5">
                        <button
                          type="button"
                          onClick={() => onUpdateQty(it.id, -10)}
                          className="w-5 h-5 flex items-center justify-center text-slate-600 hover:bg-slate-100 rounded"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-1 font-semibold text-[11px] min-w-8 text-center">
                          {it.qty}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQty(it.id, 10)}
                          className="w-5 h-5 flex items-center justify-center text-slate-600 hover:bg-slate-100 rounded"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <span className="font-bold text-[#000922] min-w-20 text-right">
                        Rs. {(it.qty * it.unitPrice).toLocaleString()}
                      </span>

                      <button
                        type="button"
                        onClick={() => onRemoveItem(it.id)}
                        className="text-red-500 hover:text-red-700 p-1 transition-colors"
                        title="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Customer & Delivery Form */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Your Full Name *
              </label>
              <input
                type="text"
                placeholder="e.g. Priyantha Silva"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-50 text-slate-900 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5]"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Contact Phone Number *
              </label>
              <input
                type="tel"
                placeholder="e.g. 077 123 4567"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-50 text-slate-900 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Delivery Town / Area *
              </label>
              <input
                type="text"
                placeholder="e.g. Malabe, Kaduwela, Maharagama"
                value={deliveryTown}
                onChange={(e) => setDeliveryTown(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-50 text-slate-900 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5]"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Estimated Distance from Malabe (KM)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  value={distanceKm}
                  onChange={(e) => setDistanceKm(Math.max(1, parseFloat(e.target.value) || 1))}
                  className="w-full px-3 py-2 rounded-lg bg-slate-50 text-slate-900 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5]"
                />
                <span className="text-slate-500 font-semibold whitespace-nowrap">KM</span>
              </div>
            </div>
          </div>

          {/* Transport Checkbox */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <input
                type="checkbox"
                id="modal-transport-check"
                checked={includeTransport}
                onChange={(e) => setIncludeTransport(e.target.checked)}
                className="w-4 h-4 rounded text-[#0051d5] focus:ring-[#0051d5] cursor-pointer"
              />
              <label htmlFor="modal-transport-check" className="font-semibold text-slate-800 cursor-pointer">
                Add Lorry Transport &amp; Site Unloading Fee
              </label>
            </div>
            <span className="font-bold text-sm text-[#0051d5]">
              Rs. {transportFee.toLocaleString()}.00
            </span>
          </div>

          {/* Site Notes */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Special Site Notes or Target Delivery Date
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Need delivery this Saturday morning. Road is 12ft wide concrete road."
              value={siteNotes}
              onChange={(e) => setSiteNotes(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-50 text-slate-900 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0051d5]"
            ></textarea>
          </div>

          {/* Grand Total Well */}
          <div className="p-4 rounded-xl bg-[#eff4ff] border border-blue-200 flex items-center justify-between">
            <span className="font-bold text-sm text-[#000922]">Final Quotation Sum:</span>
            <span className="text-2xl font-extrabold text-[#000922] font-display">
              Rs. {grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>

          {/* Real-time WhatsApp Message Preview */}
          <div className="space-y-1">
            <span className="block font-semibold text-slate-600">
              Formatted WhatsApp Message to Lahiru Gamage:
            </span>
            <pre className="p-3 rounded-xl bg-[#000922] text-emerald-300 font-mono text-[11px] leading-relaxed overflow-x-auto whitespace-pre-wrap max-h-28 border border-slate-800 select-all">
              {generateWhatsAppMessage()}
            </pre>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-5 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-white text-slate-700 font-semibold border border-slate-200 hover:bg-slate-100 transition-colors cursor-pointer text-xs"
          >
            Cancel &amp; Continue Shopping
          </button>

          <button
            type="button"
            onClick={handleLaunchWhatsApp}
            className="px-5 py-2.5 rounded-xl bg-[#16a34a] text-white font-bold text-xs sm:text-sm hover:bg-[#15803d] transition-all shadow-md active:scale-95 flex items-center gap-2 cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Confirm &amp; Launch WhatsApp Order (+94 77 205 0629)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
