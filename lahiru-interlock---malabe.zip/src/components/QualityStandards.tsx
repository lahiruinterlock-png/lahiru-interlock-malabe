import React from 'react';
import { ShieldCheck, Palette, Compass, Users, Phone, MessageSquare, Mail, MapPin, Navigation } from 'lucide-react';

export const QualityStandards: React.FC = () => {
  return (
    <section className="w-full py-12 px-4 lg:px-8 bg-white border-b border-slate-200">
      <div className="max-w-[1280px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        {/* Left: Factory Credentials & Standards (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div>
            <span className="text-[11px] font-bold text-[#0051d5] uppercase tracking-widest">
              Quality Assurance
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#000922] font-display tracking-tight mt-1">
              Engineering Standards Guaranteed
            </h2>
            <p className="text-sm text-slate-600 mt-1 leading-relaxed">
              We operate a high-volume manufacturing yard situated in Malabe, supplying civil contracts, developers, and homeowners with factory-direct pricing.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-[#eff4ff] border border-blue-100 space-y-1.5">
              <div className="flex items-center gap-2 text-[#0051d5]">
                <ShieldCheck className="w-5 h-5 shrink-0" />
                <h4 className="font-bold text-sm text-[#000922] font-display">High Crushing Strength</h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Exceeds 45 N/mm² load threshold. Capable of handling fully loaded water bowsers, delivery trucks, and SUV parking.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#eff4ff] border border-blue-100 space-y-1.5">
              <div className="flex items-center gap-2 text-[#16a34a]">
                <Palette className="w-5 h-5 shrink-0" />
                <h4 className="font-bold text-sm text-[#000922] font-display">Long-Term Color Lock</h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Premium German mineral oxides integrated into the wearing course matrix resist Sri Lankan tropical sunlight fading.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#eff4ff] border border-blue-100 space-y-1.5">
              <div className="flex items-center gap-2 text-[#0051d5]">
                <Compass className="w-5 h-5 shrink-0" />
                <h4 className="font-bold text-sm text-[#000922] font-display">True Dimensions</h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Precision machined steel molds deliver razor-sharp chamfers and 100% interlock consistency for zero-rattle laying.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#eff4ff] border border-blue-100 space-y-1.5">
              <div className="flex items-center gap-2 text-[#000922]">
                <Users className="w-5 h-5 shrink-0" />
                <h4 className="font-bold text-sm text-[#000922] font-display">Dedicated Unloading Crew</h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Every dispatch lorry is accompanied by yard workers who stack your pavers neatly at your delivery point.
              </p>
            </div>
          </div>

          {/* Direct Yard Inquiries Card */}
          <div className="p-5 rounded-2xl bg-[#e5eeff] border border-blue-200/60 space-y-3">
            <h3 className="text-lg font-bold text-[#000922] font-display">
              Yard Office &amp; Direct Inquiries
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <p className="text-slate-500 font-medium">Plant Proprietor:</p>
                <p className="text-sm font-bold text-[#000922]">Lahiru Gamage</p>
                <p className="mt-2 text-slate-500 font-medium">Direct Phone:</p>
                <p className="text-sm font-bold text-[#0051d5]">
                  <a href="tel:0772050629" className="hover:underline flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5" />
                    0772050629
                  </a>
                </p>
              </div>
              <div>
                <p className="text-slate-500 font-medium">WhatsApp Hotline:</p>
                <p className="text-sm font-bold text-[#16a34a]">
                  <a
                    href="https://wa.me/94772050629"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:underline flex items-center gap-1"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    +94 77 205 0629
                  </a>
                </p>
                <p className="mt-2 text-slate-500 font-medium">Official Email:</p>
                <p className="text-xs font-bold text-[#000922] flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-slate-500" />
                  lahiruinterlock@gmail.com
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Malabe Yard Map & Directions (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 rounded-2xl bg-[#eff4ff] border border-blue-100 space-y-4 shadow-sm">
            <div>
              <span className="text-[10px] font-bold text-[#0051d5] uppercase tracking-wider">
                Malabe Production Facility
              </span>
              <h3 className="text-xl font-bold text-[#000922] font-display mt-0.5">
                Visit Our Yard &amp; Select Samples
              </h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                1074/03, Amaragoda road, pothu arawa, Malabe, Sri Lanka. Inspect curing ponds, aggregate piles, and test compression blocks on site.
              </p>
            </div>

            {/* Map Card */}
            <div
              className="w-full h-56 bg-cover bg-center rounded-xl relative overflow-hidden shadow-inner flex items-center justify-center border border-slate-300"
              style={{
                backgroundImage: `url('https://lh3.googleusercontent.com/aida-public/AB6AXuByJ9ZRAs3ZwWcEzwk2SWkQbW-dN5_AA1c3pXOQnYFumSgNBBxERoFhaClWhVy91BKnpPOtR9DylEQmZuVUV8-93cFdxchIQJp2AgNdwIljIZ4Zjss4xd9syskeK-OhtMsPotPaxw2vW-pQycIYzITi6W1PxsjowatgIsEsopDxu9MkGI1JI6kFEMPvnU6s0ludmr0ZQ_Di1jCdNJDGznkWbh6NrgawNgoye-CfnsYEUwQoTSeBzp_rmw')`,
              }}
            >
              <div className="absolute inset-0 bg-[#000922]/50 backdrop-blur-[1px]"></div>
              <div className="relative z-10 text-center p-4 text-white space-y-1">
                <MapPin className="w-9 h-9 text-blue-300 mx-auto drop-shadow-md animate-bounce" />
                <p className="font-extrabold text-base text-white font-display">
                  Lahiru Interlock - Malabe
                </p>
                <p className="text-xs text-blue-100">Amaragoda Road, Malabe</p>
              </div>
            </div>

            <a
              href="https://maps.app.goo.gl/W9jo6oE74jPjFHz96"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3.5 rounded-xl bg-[#000922] text-white hover:bg-[#0f2042] transition-all shadow-md font-bold text-xs flex items-center justify-center gap-2 active:scale-95"
            >
              <Navigation className="w-4 h-4 text-blue-400" />
              <span>Open Google Maps Directions</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
