import React from 'react';
import { Phone, MessageSquare, MapPin, Calculator, ShieldCheck, CheckCircle2, Truck } from 'lucide-react';

interface HeroProps {
  onScrollToEstimator: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onScrollToEstimator }) => {
  return (
    <section className="w-full">
      {/* Top Status Notification Banner */}
      <div className="w-full bg-[#0f2042] text-white py-2 px-4 lg:px-8 border-b border-blue-900/50">
        <div className="max-w-[1280px] mx-auto flex flex-col md:flex-row items-center justify-between gap-2 text-center md:text-left text-xs">
          <div className="flex items-center gap-2 flex-wrap justify-center md:justify-start">
            <span className="inline-flex items-center justify-center w-2 h-2 rounded-full bg-blue-400 animate-ping"></span>
            <span className="font-bold uppercase tracking-wider text-blue-200">
              Malabe Manufacturing Yard &amp; Dispatch Hub
            </span>
            <span className="hidden lg:inline text-blue-400/40">•</span>
            <span className="hidden lg:inline text-slate-300">
              Daily Deliveries across Colombo &amp; Western Province with Manual Labor Unloading
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-slate-300">
              Yard Hotline:{' '}
              <a
                href="tel:0772050629"
                className="font-bold text-white hover:text-blue-300 transition-colors"
              >
                0772050629
              </a>
            </span>
          </div>
        </div>
      </div>

      {/* Main Hero Container */}
      <div className="w-full bg-[#eff4ff] py-10 lg:py-14 px-4 lg:px-8 border-b border-blue-100">
        <div className="max-w-[1280px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Text & Quick Actions (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white text-[#000922] shadow-xs border border-blue-200/60">
              <ShieldCheck className="w-4 h-4 text-[#0051d5]" />
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#0051d5]">
                Direct Factory Wholesale &amp; Retail
              </span>
            </div>

            <div className="space-y-3">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#000922] tracking-tight leading-[1.1] font-display">
                Premium Interlocking Paving Stones{' '}
                <span className="text-[#0051d5]">Direct From Malabe Yard</span>
              </h1>
              <p className="text-base sm:text-lg text-[#45464e] max-w-2xl leading-relaxed">
                Engineered for heavy vehicular driveways, commercial parking bays, pedestrian garden paths, and modern architectural modular walkways. Manufactured using high-density hydraulic compression.
              </p>
            </div>

            {/* Proprietor & Contact Pill */}
            <div className="p-4 rounded-xl bg-white border border-blue-100 shadow-xs flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-[#000922] flex items-center justify-center text-white shadow-xs">
                  <span className="material-symbols-outlined text-[20px]">engineering</span>
                </div>
                <div>
                  <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    Proprietor / Technical Lead
                  </p>
                  <p className="text-base font-bold text-[#000922]">Lahiru Gamage</p>
                </div>
              </div>
              <div className="flex items-center gap-2 bg-blue-50/80 px-3 py-1.5 rounded-lg border border-blue-100 text-xs">
                <MapPin className="w-3.5 h-3.5 text-[#0051d5]" />
                <span className="text-slate-600">Yard Location:</span>
                <span className="font-bold text-[#000922]">Amaragoda Road, Malabe</span>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <a
                href="tel:0772050629"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#000922] text-white hover:bg-[#0f2042] transition-all shadow-md active:scale-95 text-sm font-bold"
              >
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>Call Lahiru: 0772050629</span>
              </a>
              <a
                href="https://wa.me/94772050629?text=Hello%20Lahiru,%20I%20would%20like%20a%20quotation%20for%20interlock%20paving%20stones%20delivered%20from%20your%20Malabe%20yard."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#16a34a] text-white hover:bg-[#15803d] transition-all shadow-md active:scale-95 text-sm font-bold"
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp Quotation: 0772050629</span>
              </a>
              <a
                href="https://maps.app.goo.gl/W9jo6oE74jPjFHz96"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-3 rounded-xl bg-white text-slate-800 hover:bg-slate-50 transition-colors border border-slate-200 text-xs font-semibold shadow-xs"
              >
                <MapPin className="w-4 h-4 text-[#0051d5]" />
                <span>Visit Yard on Google Maps</span>
              </a>
              <button
                type="button"
                onClick={onScrollToEstimator}
                className="inline-flex items-center gap-2 px-4 py-3 rounded-xl bg-blue-100 text-[#0051d5] hover:bg-blue-200 transition-colors text-xs font-bold active:scale-95 cursor-pointer"
              >
                <Calculator className="w-4 h-4" />
                <span>Open Area Calculator</span>
              </button>
            </div>

            {/* Key Stat Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              <div className="p-3 rounded-xl bg-white text-center shadow-xs border border-blue-100/80">
                <p className="text-xl font-extrabold text-[#000922] font-display">4.5 Bricks</p>
                <p className="text-[11px] text-slate-500 font-bold uppercase tracking-wider mt-0.5">
                  Per Sq. Ft (8×4)
                </p>
              </div>
              <div className="p-3 rounded-xl bg-white text-center shadow-xs border border-blue-100/80">
                <p className="text-xl font-extrabold text-[#000922] font-display">9.0 Bricks</p>
                <p className="text-[11px] text-slate-500 font-bold uppercase tracking-wider mt-0.5">
                  Per Sq. Ft (4×4)
                </p>
              </div>
              <div className="p-3 rounded-xl bg-white text-center shadow-xs border border-blue-100/80">
                <p className="text-xl font-extrabold text-[#0051d5] font-display">Heavy Duty</p>
                <p className="text-[11px] text-slate-500 font-bold uppercase tracking-wider mt-0.5">
                  Site Unloading
                </p>
              </div>
              <div className="p-3 rounded-xl bg-white text-center shadow-xs border border-blue-100/80">
                <p className="text-xl font-extrabold text-[#16a34a] font-display">Factory Direct</p>
                <p className="text-[11px] text-slate-500 font-bold uppercase tracking-wider mt-0.5">
                  Best LKR Rates
                </p>
              </div>
            </div>
          </div>

          {/* Hero Visual Showcase (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="relative rounded-2xl overflow-hidden bg-[#000922] text-white shadow-xl p-5 border border-slate-800">
              <div className="relative rounded-xl overflow-hidden aspect-[4/3] mb-4 bg-slate-900 border border-white/10 group">
                <img
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuCOY20oenSmmcXLhiaW47ffrd0ruOpbuLRqI4grw77tkGfqnWo27EYNFIeJE-kocPKEdSIGylJ7ZZyb6wPR09pcRZk4vgqVNSGtypoNQm7o9n76xyQ4dPeHLk85qlahfOd5c4tvKNjfVVMS0kXw1rxKZZjKgiKQiIGaBIq2JpDBMjUmZuYIw9RCWk2UI5IOF8o6i7sTQ9mgVQcw7KDcQigHDpC3tyUU2QqYIuL5V-5WrkRDqY3NkHq_rA"
                  alt="Reinforced Interlocking Matrix Driveway"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <span className="absolute top-2.5 right-2.5 bg-[#0051d5]/90 backdrop-blur-xs text-white text-[10px] font-bold uppercase px-2.5 py-1 rounded-md">
                  Sri Lanka Standard
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-blue-300 uppercase tracking-wider text-[11px]">
                    High Compressive Capacity
                  </span>
                  <span className="text-slate-400 font-medium">SLS Grade Aggregate</span>
                </div>
                <h3 className="text-xl font-extrabold text-white font-display tracking-tight">
                  Reinforced Interlocking Matrix
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Dense cement matrix formulated to resist 10-wheeler lorry tire shear stress, monsoon water ingress, and surface micro-cracking.
                </p>
              </div>

              {/* Quick Metrics Bar */}
              <div className="grid grid-cols-3 gap-2 mt-4 pt-3 bg-[#0f2042] p-3 rounded-xl border border-blue-900/40 text-center">
                <div>
                  <p className="text-[10px] text-blue-200 uppercase font-bold tracking-wider">Strength</p>
                  <p className="text-sm font-extrabold text-white mt-0.5">&gt; 45 N/mm²</p>
                </div>
                <div>
                  <p className="text-[10px] text-blue-200 uppercase font-bold tracking-wider">Curing</p>
                  <p className="text-sm font-extrabold text-white mt-0.5">28-Day Cured</p>
                </div>
                <div>
                  <p className="text-[10px] text-blue-200 uppercase font-bold tracking-wider">Dispatch</p>
                  <p className="text-sm font-extrabold text-blue-300 mt-0.5">Same-Day</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
