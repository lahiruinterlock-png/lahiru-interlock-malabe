import React from 'react';
import { ShoppingCart, Trash2, MessageSquare } from 'lucide-react';
import { CartItem } from '../types';

interface StickyCartProps {
  items: CartItem[];
  onClearCart: () => void;
  onOpenCheckout: () => void;
}

export const StickyCart: React.FC<StickyCartProps> = ({
  items,
  onClearCart,
  onOpenCheckout,
}) => {
  const totalUnits = items.reduce((acc, it) => acc + it.qty, 0);
  const totalPrice = items.reduce((acc, it) => acc + it.qty * it.unitPrice, 0);

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 py-3 px-4 lg:px-8 shadow-2xl transition-transform duration-300">
      <div className="max-w-[1280px] mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Left: Cart Counter & Price */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-11 h-11 rounded-xl bg-[#000922] text-white shadow-xs">
            <ShoppingCart className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#0051d5] text-white text-[10px] font-bold flex items-center justify-center shadow-xs">
              {items.length}
            </span>
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">
              {items.length === 0
                ? '0 paver items selected'
                : `${totalUnits.toLocaleString()} paver units / items in cart`}
            </p>
            <p className="text-lg sm:text-xl font-extrabold text-[#000922] font-display leading-tight">
              Total: Rs. {totalPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          {items.length > 0 && (
            <button
              type="button"
              onClick={onClearCart}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-semibold hover:bg-slate-200 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5 text-red-500" />
              <span>Clear</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenCheckout}
            className="px-5 py-2.5 rounded-xl bg-[#16a34a] text-white text-xs sm:text-sm font-bold hover:bg-[#15803d] transition-all shadow-md active:scale-95 flex items-center gap-2 cursor-pointer"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Review &amp; Checkout via WhatsApp</span>
          </button>
        </div>
      </div>
    </div>
  );
};
