/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { EstimatorSuite } from './components/EstimatorSuite';
import { ProductCatalog } from './components/ProductCatalog';
import { QualityStandards } from './components/QualityStandards';
import { Footer } from './components/Footer';
import { StickyCart } from './components/StickyCart';
import { CheckoutModal } from './components/CheckoutModal';
import { CartItem, ToastMessage } from './types';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Toast notification helper
  const showToast = (text: string) => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, text }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 2800);
  };

  // Add item to cart
  const handleAddToCart = (item: CartItem) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex((i) => i.id === item.id);
      if (existingIndex > -1) {
        const copy = [...prev];
        copy[existingIndex] = {
          ...copy[existingIndex],
          qty: copy[existingIndex].qty + item.qty,
        };
        return copy;
      }
      return [...prev, item];
    });
  };

  // Update item quantity
  const handleUpdateQty = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.qty + delta;
            return newQty > 0 ? { ...item, qty: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  // Remove single item
  const handleRemoveItem = (id: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  // Clear entire cart
  const handleClearCart = () => {
    setCart([]);
    showToast('Cart cleared.');
  };

  // Navigation handlers
  const handleSelectCategory = (category: string) => {
    setActiveCategory(category);
    const catalogEl = document.getElementById('product-catalog');
    if (catalogEl) {
      catalogEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollToEstimators = () => {
    const el = document.getElementById('estimation-suite');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f8f9ff] text-[#0b1c30]">
      {/* Toast Notification Container */}
      <div className="fixed top-24 right-4 z-50 flex flex-col gap-2 pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="bg-[#000922] text-white px-4 py-2.5 rounded-xl shadow-xl text-xs font-semibold flex items-center gap-2 border border-slate-700 animate-in fade-in slide-in-from-top-2 duration-200"
          >
            <CheckCircle2 className="w-4 h-4 text-[#16a34a] shrink-0" />
            <span>{toast.text}</span>
          </div>
        ))}
      </div>

      {/* Main Header */}
      <Header
        cartItemCount={cart.length}
        onOpenCart={() => setIsCheckoutOpen(true)}
        onSelectCategory={handleSelectCategory}
        onScrollToEstimators={handleScrollToEstimators}
        activeCategory={activeCategory}
      />

      {/* Page Content */}
      <main className="flex-1 w-full">
        {/* Hero Section */}
        <Hero onScrollToEstimator={handleScrollToEstimators} />

        {/* Interactive Estimator Suite */}
        <EstimatorSuite
          onAddToCart={handleAddToCart}
          showToast={showToast}
        />

        {/* Product Catalog */}
        <ProductCatalog
          activeCategory={activeCategory}
          onSelectCategory={setActiveCategory}
          onAddToCart={handleAddToCart}
          showToast={showToast}
        />

        {/* Quality Standards & Yard Facility */}
        <QualityStandards />
      </main>

      {/* Footer */}
      <Footer />

      {/* Sticky Bottom Cart Dock */}
      <StickyCart
        items={cart}
        onClearCart={handleClearCart}
        onOpenCheckout={() => setIsCheckoutOpen(true)}
      />

      {/* Checkout & WhatsApp Order Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cart}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />
    </div>
  );
}
